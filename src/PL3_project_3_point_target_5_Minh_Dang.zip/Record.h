#pragma once

#include "Key.h"

typedef Key Record;

